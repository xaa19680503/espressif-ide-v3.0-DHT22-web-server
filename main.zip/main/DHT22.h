#ifndef DHT22_H_
#define DHT22_H_
#include "soc/gpio_num.h"
#define DHT_OK 0
#define DHT_CHECKSUM_ERROR -1
#define DHT_TIMEOUT_ERROR -2
// == function prototypes =====================
void setDHTgpio(gpio_num_t gpio);
void errorHandler(int response);
int readDHT();
float getHumidity();
float getTemperature();
int getSignalLevel( int usTimeOut, bool state );
#endif